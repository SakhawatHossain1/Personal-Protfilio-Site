$(document).ready(function(){
	jQuery(".header_menu #bar").click(function(){
		jQuery(".header_menu ul").slideToggle();

		return false;
	});
		jQuery(window).resize(function(){

		var screenWidth = jQuery(window).width();

		if(screenWidth > 768){
			jQuery(".header_menu ul").removeAttr("style");
		}
	});
});
